const fs = require('fs');
let code = fs.readFileSync('src/components/ReportsView.tsx', 'utf8');

const target = `const handleExportReportXLSX = () => {`;
const replacement = `const handleExportReportXLSX = () => {
    if (reportType === "pri") {
      const docElem = document.getElementById("reportDocContent");
      if (!docElem) return;
      const table = docElem.querySelector("table");
      if (!table) return;
      const wb = XLSX.utils.table_to_book(table);
      const semLabel = SEMESTERS.find(s => s.id === (semester !== "annual" ? semester : "s1"))?.label || semester;
      XLSX.writeFile(wb, \`pri_report_\${selClass}_\${semLabel}.xlsx\`);
      toast("📥 Export Excel រួចរាល់");
      return;
    }`;

if (code.includes(target) && !code.includes('const wb = XLSX.utils.table_to_book(table);')) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/components/ReportsView.tsx', code);
  console.log("Patched xlsx for PRI");
}

const fs = require('fs');
let code = fs.readFileSync('src/components/ReportsView.tsx', 'utf8');

const exportXlsxFunc = `
  const handleExportReportXLSX = () => {
    if (reportType === "semester") {
      const semId = semester !== "annual" ? semester : "s1";
      
      const rows = [
        ["ល.រ", "គោត្តនាម-នាម", "ភេទ", "ថ្ងៃខែឆ្នាំកំណើត", "មធ្យមភាគខែ", "ម.ប្រឡង", "ម.ប្រចាំឆមាស", "ចំ.ថ្នាក់", "និទ្ទេស"]
      ];

      ranked.forEach((s, i) => {
        const getStudentSemesterExamAvgLocal = (sid) => {
          let examScores = undefined;
          if (semId === "s1") {
            examScores = allMonthsScores?.["s1_3"]?.[sid];
          } else if (semId === "s2") {
            examScores = allMonthsScores?.["s2_7"]?.[sid] || allMonthsScores?.["s2_8"]?.[sid];
          }
          if ((!examScores || Object.keys(examScores).length === 0) && semId === semester) {
            examScores = scoresMap[sid];
          }
          if (!examScores) return 0;
          let total = 0, hasAny = false;
          SUBJECTS.forEach(sub => {
            const v = examScores[sub];
            if (v !== undefined && v !== "" && v !== null && !isNaN(Number(v))) {
              total += Number(v);
              hasAny = true;
            }
          });
          if (!hasAny) return 0;
          const evalCount = getClassEvalSubjectCount(students, scoresMap);
          return truncate2(total / evalCount);
        };
        
        const examAvg = getStudentSemesterExamAvgLocal(s.id);
        const semMonthlyAvg = getStudentSemesterMonthlyAvg(s.id);
        const numMonthlyAvg = Number(semMonthlyAvg);
        let semAvgVal = 0;
        if (!isNaN(numMonthlyAvg) && numMonthlyAvg > 0 && examAvg > 0) {
          semAvgVal = (numMonthlyAvg + examAvg) / 2;
        } else if (!isNaN(numMonthlyAvg) && numMonthlyAvg > 0) {
          semAvgVal = numMonthlyAvg;
        } else if (examAvg > 0) {
          semAvgVal = examAvg;
        }
        
        const g = gradeOf(semAvgVal);
        
        rows.push([
          i + 1,
          \`\${s.lastName} \${s.firstName}\`,
          s.gender === "ស្រី" ? "ស្រី" : "ប្រុស",
          s.dob || "",
          numMonthlyAvg > 0 ? numMonthlyAvg : "",
          examAvg > 0 ? Number(fmtAvg(examAvg)) : "",
          semAvgVal > 0 ? Number(fmtAvg(semAvgVal)) : "",
          s._rank || i + 1,
          g.l
        ]);
      });

      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), "ចំណាត់ថ្នាក់ឆមាស");
      const semLabel = SEMESTERS.find((x) => x.id === semester)?.label || semester;
      XLSX.writeFile(wb, \`semester_report_\${selClass}_\${semLabel}.xlsx\`);
      toast("📥 Export Excel រួចរាល់");

    } else if (reportType === "annual") {
      const annualData = computeAnnualDataForStudents();
      const dataToRender = [...annualData].sort((a, b) => {
        if (a.annualAvg !== null && b.annualAvg !== null) {
          if (a.annualAvg !== b.annualAvg) return b.annualAvg - a.annualAvg;
        }
        if (a.annualAvg !== null && b.annualAvg === null) return -1;
        if (a.annualAvg === null && b.annualAvg !== null) return 1;
        return (a.student.lastName || "").localeCompare(b.student.lastName || "", "km");
      });

      const rows = [
        ["ល.រ", "គោត្តនាម-នាម", "ភេទ", "ថ្ងៃខែឆ្នាំកំណើត", "ទីលំនៅបច្ចុប្បន្ន (ភូមិ-ឃុំ-ស្រុក-ខេត្ត)", "ម.ប្រចាំឆ១", "ចំ.ថ្នាក់ឆ១", "ម.ប្រចាំឆ២", "ចំ.ថ្នាក់ឆ២", "ម.ប្រចាំឆ្នាំ", "ចំ.ថ្នាក់ឆ្នាំ", "និទ្ទេស", "អវត្តមានច្បាប់", "អវត្តមានឥតច្បាប់", "អវត្តមានសរុប"]
      ];

      dataToRender.forEach((row, i) => {
        const s = row.student;
        const fullName = \`\${s.lastName || ""} \${s.firstName || ""}\`.trim();
        const addrParts = [];
        if (s.village) addrParts.push(s.village.startsWith("ភូមិ") ? s.village : \`ភូមិ\${s.village}\`);
        if (s.commune) addrParts.push(s.commune.startsWith("ឃុំ") || s.commune.startsWith("សង្កាត់") ? s.commune : \`ឃុំ\${s.commune}\`);
        if (s.district) addrParts.push(s.district.startsWith("ស្រុក") || s.district.startsWith("ក្រុង") || s.district.startsWith("ខណ្ឌ") ? s.district : \`ស្រុក\${s.district}\`);
        if (s.province) addrParts.push(s.province.startsWith("ខេត្ត") || s.province.startsWith("រាជធានី") ? s.province : \`ខេត្ត\${s.province}\`);
        const address = addrParts.join(" ") || "";
        const gradeInfo = row.annualAvg !== null ? gradeOf(row.annualAvg) : { l: "" };

        rows.push([
          i + 1,
          fullName,
          s.gender || "",
          s.dob || "",
          address,
          row.s1Avg !== null ? Number(fmtAvg(row.s1Avg)) : "",
          row.s1Rank !== null ? row.s1Rank : "",
          row.s2Avg !== null ? Number(fmtAvg(row.s2Avg)) : "",
          row.s2Rank !== null ? row.s2Rank : "",
          row.annualAvg !== null ? Number(fmtAvg(row.annualAvg)) : "",
          row.annualRank !== null ? row.annualRank : "",
          gradeInfo.l,
          row.absences.p,
          row.absences.u,
          row.absences.total
        ]);
      });

      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), "ចំណាត់ថ្នាក់ដំណាច់ឆ្នាំ");
      XLSX.writeFile(wb, \`annual_report_\${selClass}.xlsx\`);
      toast("📥 Export Excel រួចរាល់");
    }
  };
`;

const printHandlerTarget = /\/\/\s*Print Handler\s*const handlePrintReport = \(\) => \{/;

if (code.match(printHandlerTarget)) {
  code = code.replace(printHandlerTarget, exportXlsxFunc + "\n\n  // Print Handler\n  const handlePrintReport = () => {");
  fs.writeFileSync('src/components/ReportsView.tsx', code);
  console.log("XLSX function injected");
} else {
  console.log("Failed to inject XLSX function");
}

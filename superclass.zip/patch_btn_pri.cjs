const fs = require('fs');
let code = fs.readFileSync('src/components/ReportsView.tsx', 'utf8');

const target = `{(reportType === "semester" || reportType === "annual") && (`;
const replacement = `{(reportType === "semester" || reportType === "annual" || reportType === "pri") && (`;

if (code.includes(target) && !code.includes(replacement)) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/components/ReportsView.tsx', code);
  console.log("Patched print btn for PRI");
}

const fs = require('fs');
let code = fs.readFileSync('src/components/ReportsView.tsx', 'utf8');

const target = `            <button
              onClick={handlePrintReport}
              className="bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs px-3 py-1.5 rounded-xl transition shadow-xs flex items-center gap-1"
            >
              <span>🖨️</span> <span>ព្រីន PDF</span>
            </button>`;

const replacement = `            <button
              onClick={handlePrintReport}
              className="bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs px-3 py-1.5 rounded-xl transition shadow-xs flex items-center gap-1"
            >
              <span>🖨️</span> <span>ព្រីន PDF</span>
            </button>
            {(reportType === "semester" || reportType === "annual") && (
              <button
                onClick={handleExportReportXLSX}
                className="bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs px-3 py-1.5 rounded-xl transition shadow-xs flex items-center gap-1"
                title="ទាញយករាយនាម និងចំណាត់ថ្នាក់ជាឯកសារ Excel"
              >
                <span>📥</span> <span>Excel</span>
              </button>
            )}`;

if (code.includes(target)) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/components/ReportsView.tsx', code);
  console.log("Button injected");
} else {
  console.log("Failed to inject button");
}

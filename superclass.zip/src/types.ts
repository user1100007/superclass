export interface TeacherProfile {
  uid: string;
  fullName: string;
  title: string;
  phone: string;
  email: string;
  school: string;
  schoolID: string;
  level: string;
  province: string;
  district: string;
  commune: string;
  village: string;
  position?: string;
  createdAt: number;
}

export interface Student {
  id: string;
  code?: string;
  lastName: string;
  firstName: string;
  gender: 'ប្រុស' | 'ស្រី' | string;
  dob?: string;
  age?: string;
  fatherName?: string;
  fatherJob?: string;
  motherName?: string;
  motherJob?: string;
  village?: string;
  commune?: string;
  district?: string;
  province?: string;
  phone?: string;
  photoUrl?: string;
  latinName?: string;
  _rank?: number;
}

export interface ScoreMap {
  [subject: string]: number | string;
}

export interface AttendanceMap {
  [day: number]: 'P' | 'A' | '';
}

export interface SupervisorInfo {
  name: string;
  phone: string;
  sig: string;
}

export interface InvigilatorData {
  building: string;
  room: string;
  shift: 'ព្រឹក' | 'ល្ងាច' | string;
  sup1: SupervisorInfo;
  sup2: SupervisorInfo;
}

export interface CoreGradeRecord {
  khmerComponents: Record<string, string | null>;
  khmerAvg: number | null;
  khmerGrade: string | null;
  mathComponents: Record<string, string | null>;
  mathAvg: number | null;
  mathGrade: string | null;
  savedAt?: string;
}

export type InnerTab = 'info' | 'scores' | 'attendance' | 'detail' | 'report' | 'schoolreport' | 'candidate' | 'certificate' | 'honor' | 'gradeanalysis';

export type ReportType = 'monthly' | 'semester' | 'detail' | 'annual' | 'attendance' | 'studentcard' | 'candidate' | 'certificate' | 'coregrade' | 'traineebook';

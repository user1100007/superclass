import React, { useState } from "react";
import { Student, ScoreMap, AttendanceMap, TeacherProfile, InvigilatorData, ReportType } from "../types";
import {
  MONTHS, SEMESTERS, SUBJECTS,
  fmtAvg, gradeOf, resultOf, getTotal, getAvg, getRank, buildRankedList,
  KH_ORDER, MT_ORDER, computeReportStats, toKhNum, getClassEvalSubjectCount
} from "../lib/constants";
import {
  buildSignatureHtml, buildInvigilatorBoxHTML, buildCandidateDocHTML, buildCertificateHTML,
  buildStudentCardHTML, buildTraineeBookHTML, printHTML, generateStudentQRCodeDataUrl
} from "../lib/printUtils";
import { buildHonorAllPrintHTML, buildHonorTop5PrintHTML } from "../lib/printUtilsHelpers";
import * as XLSX from "xlsx";

interface ReportsViewProps {
  students: Student[];
  scoresMap: Record<string, ScoreMap>;
  attendanceMap: Record<string, AttendanceMap>;
  honorPhotos: Record<string, string>;
  selClass: string;
  semester: string;
  selMonth: number;
  teacher: TeacherProfile | null;
  invigilatorData: InvigilatorData;
  reportType: ReportType;
  onReportTypeChange: (type: ReportType) => void;
  onOpenInvigilatorModal: () => void;
  onOpenVerifyModal: (student: Student) => void;
  onSaveCoreGrades: () => Promise<void>;
  toast: (msg: string, type?: "success" | "error" | "info") => void;
  allMonthsScores?: Record<string, Record<string, ScoreMap>>;
  onOpenGmailModal?: (params?: { recipient?: string; subject?: string; htmlBody?: string }) => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  students,
  scoresMap,
  attendanceMap,
  honorPhotos,
  selClass,
  semester,
  selMonth,
  teacher,
  invigilatorData,
  reportType,
  onReportTypeChange,
  onOpenInvigilatorModal,
  onOpenVerifyModal,
  onSaveCoreGrades,
  toast,
  allMonthsScores = {},
  onOpenGmailModal,
}) => {
  const [selectedStudentId, setSelectedStudentId] = useState<string>("__all__");
  const [studentCardSem, setStudentCardSem] = useState<string>(semester !== "annual" ? semester : "s1");

  // Certificate & Student List Filtering States
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [genderFilter, setGenderFilter] = useState<string>("all");
  const [resultFilter, setResultFilter] = useState<string>("all");
  const [gradeFilter, setGradeFilter] = useState<string>("all");
  const [certQrUrls, setCertQrUrls] = useState<Record<string, string>>({});
  const [isGeneratingQr, setIsGeneratingQr] = useState<boolean>(false);

  const tName = `${teacher?.title || ""} ${teacher?.fullName || ""}`.trim();
  const schoolName = teacher?.school || "សាលាបឋមសិក្សា";

  // Compute Filtered Students based on search, gender, result, grade, and student selection
  const filteredStudents = students.filter((s) => {
    if (selectedStudentId !== "__all__" && s.id !== selectedStudentId) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const fullName = `${s.lastName || ""} ${s.firstName || ""} ${s.latinName || ""} ${s.code || ""}`.toLowerCase();
      if (!fullName.includes(q)) return false;
    }

    if (genderFilter !== "all" && s.gender !== genderFilter) return false;

    const annualAvg = getAvg(s.id, students, scoresMap);
    const avgVal = annualAvg !== null ? Number(fmtAvg(annualAvg)) : null;

    if (resultFilter !== "all") {
      const isPass = avgVal !== null && avgVal >= 5.0;
      if (resultFilter === "pass" && !isPass) return false;
      if (resultFilter === "fail" && isPass) return false;
    }

    if (gradeFilter !== "all") {
      const g = avgVal !== null ? gradeOf(avgVal).l : "F";
      if (g !== gradeFilter) return false;
    }

    return true;
  });

  // Pre-generate QR Codes for Web Preview when reportType is certificate
  React.useEffect(() => {
    if (reportType === "certificate") {
      let active = true;
      const generateAll = async () => {
        setIsGeneratingQr(true);
        const newUrls: Record<string, string> = {};
        for (const s of filteredStudents) {
          const annualAvg = getAvg(s.id, students, scoresMap);
          const avgVal = annualAvg !== null ? Number(fmtAvg(annualAvg)) : null;
          const g = avgVal !== null ? gradeOf(avgVal).l : "—";
          const rank = getRank(s.id, students, scoresMap);
          const url = await generateStudentQRCodeDataUrl(s, selClass, schoolName, avgVal, g, rank);
          newUrls[s.id] = url;
        }
        if (active) {
          setCertQrUrls(newUrls);
          setIsGeneratingQr(false);
        }
      };
      generateAll();
      return () => {
        active = false;
      };
    }
  }, [reportType, filteredStudents.length, selectedStudentId, searchQuery, genderFilter, resultFilter, gradeFilter, selClass, schoolName]);

  const getStudentSemesterMonthlyAvg = (sid: string): string => {
    const semId = semester !== "annual" ? semester : "s1";
    const semConfig = SEMESTERS.find((s) => s.id === semId) || SEMESTERS[0];
    const months = semConfig.months;

    const mAvgs = months.map((mIdx) => {
      const key = `${semId}_${mIdx}`;
      const monthData = allMonthsScores?.[key] || {};
      let stuScores = monthData[sid];
      if ((!stuScores || Object.keys(stuScores).length === 0) && semId === semester && mIdx === selMonth) {
        stuScores = scoresMap[sid];
      }
      if (!stuScores) return null;
      const keys = Object.keys(stuScores).filter(
        (k) => stuScores![k] !== "" && stuScores![k] !== undefined && !isNaN(Number(stuScores![k]))
      );
      if (!keys.length) return null;
      const sum = keys.reduce((acc, k) => acc + Number(stuScores![k]), 0);
      return sum / keys.length;
    });

    const firstThree = mAvgs.slice(0, 3).filter((v): v is number => v !== null);
    const validMAvgs = mAvgs.filter((v): v is number => v !== null);

    let monthlyAvg: number | null = null;
    if (firstThree.length > 0) {
      monthlyAvg = firstThree.reduce((a, b) => a + b, 0) / firstThree.length;
    } else if (validMAvgs.length > 0) {
      monthlyAvg = validMAvgs.reduce((a, b) => a + b, 0) / validMAvgs.length;
    }

    if (monthlyAvg !== null) {
      return fmtAvg(monthlyAvg);
    }

    const fallbackAvg = getAvg(sid, students, scoresMap);
    return fallbackAvg > 0 ? fmtAvg(fallbackAvg) : "—";
  };

  const ranked = buildRankedList(students, scoresMap);
  const stats = computeReportStats(students, scoresMap);
  const halfIndex = Math.ceil(ranked.length / 2);
  const leftRanked = ranked.slice(0, halfIndex);
  const rightRanked = ranked.slice(halfIndex);

  // Helper to render student ranking table chunk with equal height padding
  const targetRows = Math.max(leftRanked.length, rightRanked.length);

  const renderRankTable = (list: Student[], startIdx: number) => {
    const missingRows = Math.max(0, targetRows - list.length);
    const isSemester = reportType === "semester";

    return (
      <table className="rank-table w-full border-collapse border border-slate-300 text-[13px]">
        <thead>
          <tr className="bg-blue-100/90 border border-slate-300">
            <th className="border border-slate-300 py-2.5 px-1 text-center w-7">ល.រ</th>
            <th className="border border-slate-300 py-2.5 px-1.5 text-left min-w-[100px]">គោត្តនាម-នាម</th>
            <th className="border border-slate-300 py-2.5 px-1 text-center w-8">ភេទ</th>
            <th className="border border-slate-300 py-2.5 px-1 text-center min-w-[70px]">ថ្ងៃខែឆ្នាំកំណើត</th>
            {isSemester ? (
              <>
                <th className="border border-slate-300 py-2.5 px-1 text-center w-12">មធ្យមភាគខែ</th>
                <th className="border border-slate-300 py-2.5 px-1 text-center w-12">ម.ប្រឡង</th>
                <th className="border border-slate-300 py-2.5 px-1 text-center w-12">ម.ប្រចាំឆមាស</th>
              </>
            ) : (
              <>
                <th className="border border-slate-300 py-2.5 px-1 text-center w-12">ពិន្ទុសរុប</th>
                <th className="border border-slate-300 py-2.5 px-1 text-center w-12">ម.ប្រឡង</th>
              </>
            )}
            <th className="border border-slate-300 py-2.5 px-1 text-center w-10">ចំ.ថ្នាក់</th>
            <th className="border border-slate-300 py-2.5 px-1 text-center w-10">និទ្ទេស</th>
          </tr>
        </thead>
        <tbody>
          {list.map((s, idx) => {
            const rowIdx = startIdx + idx;
            const total = getTotal(s.id, scoresMap);
            const examAvg = getAvg(s.id, students, scoresMap);
            const semMonthlyAvg = getStudentSemesterMonthlyAvg(s.id);
            const numMonthlyAvg = Number(semMonthlyAvg);

            let semAvgVal = 0;
            if (!isNaN(numMonthlyAvg) && numMonthlyAvg > 0 && examAvg > 0) {
              semAvgVal = (numMonthlyAvg + examAvg) / 2;
            } else if (!isNaN(numMonthlyAvg) && numMonthlyAvg > 0) {
              semAvgVal = numMonthlyAvg;
            } else if (examAvg > 0) {
              semAvgVal = examAvg;
            }

            const finalAvg = isSemester ? semAvgVal : examAvg;
            const g = gradeOf(finalAvg);

            return (
              <tr key={s.id} className={idx % 2 === 0 ? "bg-slate-50/50" : "bg-white"}>
                <td className="border border-slate-300 py-2.5 px-1 text-center font-semibold">{rowIdx + 1}</td>
                <td className="border border-slate-300 py-2.5 px-1.5 text-left font-bold text-slate-800 whitespace-nowrap">
                  {s.lastName} {s.firstName}
                </td>
                <td className="border border-slate-300 py-2.5 px-1 text-center">{s.gender === "ស្រី" ? "ស្រី" : "ប្រុស"}</td>
                <td className="border border-slate-300 py-2.5 px-1 text-center text-slate-600 text-[11.5px] whitespace-nowrap">{s.dob || "—"}</td>
                {isSemester ? (
                  <>
                    <td className="border border-slate-300 py-2.5 px-1 text-center font-extrabold text-blue-700">{semMonthlyAvg}</td>
                    <td className="border border-slate-300 py-2.5 px-1 text-center font-extrabold">{fmtAvg(examAvg)}</td>
                    <td className="border border-slate-300 py-2.5 px-1 text-center font-extrabold text-indigo-700">{fmtAvg(semAvgVal)}</td>
                  </>
                ) : (
                  <>
                    <td className="border border-slate-300 py-2.5 px-1 text-center font-extrabold text-blue-700">{total}</td>
                    <td className="border border-slate-300 py-2.5 px-1 text-center font-extrabold">{fmtAvg(examAvg)}</td>
                  </>
                )}
                <td className="border border-slate-300 py-2.5 px-1 text-center font-bold">{s._rank || rowIdx + 1}</td>
                <td className="border border-slate-300 py-2.5 px-1 text-center font-black" style={{ color: g.c }}>
                  {g.l}
                </td>
              </tr>
            );
          })}
          {Array.from({ length: missingRows }).map((_, i) => (
            <tr key={`empty-${i}`} className={(list.length + i) % 2 === 0 ? "bg-slate-50/50" : "bg-white"}>
              <td className="border border-slate-300 py-2.5 px-1 text-center text-transparent">&nbsp;</td>
              <td className="border border-slate-300 py-2.5 px-1.5 text-left text-transparent">&nbsp;</td>
              <td className="border border-slate-300 py-2.5 px-1 text-transparent">&nbsp;</td>
              <td className="border border-slate-300 py-2.5 px-1 text-transparent">&nbsp;</td>
              <td className="border border-slate-300 py-2.5 px-1 text-transparent">&nbsp;</td>
              <td className="border border-slate-300 py-2.5 px-1 text-transparent">&nbsp;</td>
              <td className="border border-slate-300 py-2.5 px-1 text-transparent">&nbsp;</td>
              <td className="border border-slate-300 py-2.5 px-1 text-transparent">&nbsp;</td>
              {isSemester && <td className="border border-slate-300 py-2.5 px-1 text-transparent">&nbsp;</td>}
            </tr>
          ))}
        </tbody>
      </table>
    );
  };
  const computeCoreGradeRow = (s: Student) => {
    const khRaw = KH_ORDER.map((subj) => scoresMap[s.id]?.[subj]);
    const mtRaw = MT_ORDER.map((subj) => scoresMap[s.id]?.[subj]);
    const khGrades = khRaw.map((v) =>
      v !== "" && v !== undefined && !isNaN(Number(v)) ? gradeOf(Number(v)).l : null
    );
    const mtGrades = mtRaw.map((v) =>
      v !== "" && v !== undefined && !isNaN(Number(v)) ? gradeOf(Number(v)).l : null
    );

    const khValids = khRaw.filter((v) => v !== "" && v !== undefined && !isNaN(Number(v))).map(Number);
    const mtValids = mtRaw.filter((v) => v !== "" && v !== undefined && !isNaN(Number(v))).map(Number);

    const khAvg = khValids.length ? khValids.reduce((a, b) => a + b, 0) / khValids.length : null;
    const mtAvg = mtValids.length ? mtValids.reduce((a, b) => a + b, 0) / mtValids.length : null;

    const khCombined = khAvg !== null ? gradeOf(khAvg).l : null;
    const mtCombined = mtAvg !== null ? gradeOf(mtAvg).l : null;

    return { khGrades, mtGrades, khAvg, mtAvg, khCombined, mtCombined };
  };

  const computeAnnualDataForStudents = () => {
    const getSemesterAvgForStudent = (sid: string, semId: "s1" | "s2") => {
      const semConfig = SEMESTERS.find((s) => s.id === semId);
      if (!semConfig) return null;
      const months = semConfig.months;
      const mAvgs: number[] = [];

      months.forEach((mIdx) => {
        const key = `${semId}_${mIdx}`;
        const monthData = allMonthsScores?.[key];
        if (monthData && monthData[sid]) {
          const stuScores = monthData[sid];
          const valids = Object.values(stuScores)
            .filter((v) => v !== "" && v !== null && v !== undefined && !isNaN(Number(v)))
            .map(Number);
          if (valids.length > 0) {
            const sum = valids.reduce((a, b) => a + b, 0);
            const evalCount = getClassEvalSubjectCount(students, scoresMap);
            mAvgs.push(sum / evalCount);
          }
        }
      });

      if (mAvgs.length > 0) {
        return mAvgs.reduce((a, b) => a + b, 0) / mAvgs.length;
      }
      return null;
    };

    const rawData = students.map((s) => {
      const s1Avg = getSemesterAvgForStudent(s.id, "s1");
      const s2Avg = getSemesterAvgForStudent(s.id, "s2");

      let annualAvg: number | null = null;
      if (s1Avg !== null && s2Avg !== null) {
        annualAvg = (s1Avg + s2Avg) / 2;
      } else if (s1Avg !== null) {
        annualAvg = s1Avg;
      } else if (s2Avg !== null) {
        annualAvg = s2Avg;
      } else {
        const fallbackAvg = getAvg(s.id, students, scoresMap);
        annualAvg = fallbackAvg > 0 ? fallbackAvg : null;
      }

      const stuAtt = attendanceMap[s.id] || {};
      const attVals = Object.values(stuAtt);
      const pCount = attVals.filter((v) => v === "P").length;
      const aCount = attVals.filter((v) => v === "A").length;
      const totalAbs = pCount + aCount;

      return {
        student: s,
        s1Avg,
        s2Avg,
        annualAvg,
        pCount,
        aCount,
        totalAbs,
      };
    });

    const sortedS1 = [...rawData]
      .filter((r) => r.s1Avg !== null)
      .sort((a, b) => (b.s1Avg || 0) - (a.s1Avg || 0));
    const s1RankMap: Record<string, number> = {};
    sortedS1.forEach((item, idx) => {
      if (idx > 0 && item.s1Avg === sortedS1[idx - 1].s1Avg) {
        s1RankMap[item.student.id] = s1RankMap[sortedS1[idx - 1].student.id];
      } else {
        s1RankMap[item.student.id] = idx + 1;
      }
    });

    const sortedS2 = [...rawData]
      .filter((r) => r.s2Avg !== null)
      .sort((a, b) => (b.s2Avg || 0) - (a.s2Avg || 0));
    const s2RankMap: Record<string, number> = {};
    sortedS2.forEach((item, idx) => {
      if (idx > 0 && item.s2Avg === sortedS2[idx - 1].s2Avg) {
        s2RankMap[item.student.id] = s2RankMap[sortedS2[idx - 1].student.id];
      } else {
        s2RankMap[item.student.id] = idx + 1;
      }
    });

    const sortedAnnual = [...rawData]
      .filter((r) => r.annualAvg !== null)
      .sort((a, b) => (b.annualAvg || 0) - (a.annualAvg || 0));
    const annualRankMap: Record<string, number> = {};
    sortedAnnual.forEach((item, idx) => {
      if (idx > 0 && item.annualAvg === sortedAnnual[idx - 1].annualAvg) {
        annualRankMap[item.student.id] = annualRankMap[sortedAnnual[idx - 1].student.id];
      } else {
        annualRankMap[item.student.id] = idx + 1;
      }
    });

    return rawData.map((item) => ({
      ...item,
      s1Rank: item.s1Avg !== null ? (s1RankMap[item.student.id] ?? null) : null,
      s2Rank: item.s2Avg !== null ? (s2RankMap[item.student.id] ?? null) : null,
      annualRank: item.annualAvg !== null ? (annualRankMap[item.student.id] ?? null) : null,
    }));
  };

  const renderAnnualReportTable = () => {
    const annualData = computeAnnualDataForStudents();

    return (
      <div className="overflow-x-auto w-full">
        <table className="w-full border-collapse border border-slate-300 text-[11px] text-center" style={{ width: "100%", borderCollapse: "collapse", border: "1px solid #cbd5e1" }}>
          <thead>
            <tr className="bg-blue-100/90 text-slate-900 font-bold" style={{ backgroundColor: "#dbeafe", color: "#0f172a" }}>
              <th rowSpan={2} className="border border-slate-300 p-1 text-center" style={{ width: "29px", border: "1px solid #cbd5e1", padding: "4px" }}>
                <p>ល.រ</p>
              </th>
              <th rowSpan={2} className="border border-slate-300 p-1 text-left whitespace-nowrap" style={{ width: "137px", border: "1px solid #cbd5e1", padding: "4px", textAlign: "left" }}>
                <p>គោត្តនាម- នាម</p>
              </th>
              <th rowSpan={2} className="border border-slate-300 p-1 text-center" style={{ width: "32px", border: "1px solid #cbd5e1", padding: "4px" }}>
                <p>ភេទ</p>
              </th>
              <th rowSpan={2} className="border border-slate-300 p-1 text-center" style={{ width: "112px", border: "1px solid #cbd5e1", padding: "4px", textAlign: "center" }}>
                <p style={{ textAlign: "center" }}>ថ្ងៃខែឆ្នាំកំណើត</p>
              </th>
              <th rowSpan={2} className="border border-slate-300 p-1 text-left whitespace-nowrap" style={{ minWidth: "220px", width: "250px", border: "1px solid #cbd5e1", padding: "4px", textAlign: "left" }}>
                <p>ទីលំនៅបច្ចុប្បន្ន (ភូមិ-ឃុំ-ស្រុក-ខេត្ត)</p>
              </th>
              <th colSpan={2} className="border border-slate-300 p-1 text-center" style={{ width: "117px", border: "1px solid #cbd5e1", padding: "4px", textAlign: "center" }}>
                <p style={{ textAlign: "center" }}>មធ្យមភាគប្រចាំឆ១</p>
              </th>
              <th colSpan={2} className="border border-slate-300 p-1 text-center" style={{ width: "112px", border: "1px solid #cbd5e1", padding: "4px", textAlign: "center" }}>
                <p style={{ textAlign: "center" }}>មធ្យមភាគប្រចាំឆ២</p>
              </th>
              <th colSpan={2} className="border border-slate-300 p-1 text-center" style={{ width: "118px", border: "1px solid #cbd5e1", padding: "4px", textAlign: "center" }}>
                <p style={{ textAlign: "center" }}>មធ្យមប្រចាំឆ្នាំសិក្សា</p>
              </th>
              <th rowSpan={2} className="border border-slate-300 p-1 text-center" style={{ width: "61px", border: "1px solid #cbd5e1", padding: "4px" }}>
                <p>និទ្ទេស</p>
              </th>
              <th colSpan={3} className="border border-slate-300 p-1 text-center" style={{ width: "98px", border: "1px solid #cbd5e1", padding: "4px", textAlign: "center" }}>
                <p style={{ textAlign: "center" }}>អវត្តមានសរុប</p>
              </th>
            </tr>
            <tr className="bg-blue-100/90 text-slate-900 font-bold text-[10px]" style={{ backgroundColor: "#dbeafe", color: "#0f172a" }}>
              <th className="border border-slate-300 p-1" style={{ width: "62px", border: "1px solid #cbd5e1", padding: "4px" }}>
                <p>មធ្យមភាគ</p>
              </th>
              <th className="border border-slate-300 p-1" style={{ width: "48px", border: "1px solid #cbd5e1", padding: "4px" }}>
                <p>ចំណាត់ថ្នាក់</p>
              </th>
              <th className="border border-slate-300 p-1" style={{ width: "57px", border: "1px solid #cbd5e1", padding: "4px" }}>
                <p>មធ្យមភាគ</p>
              </th>
              <th className="border border-slate-300 p-1" style={{ width: "48px", border: "1px solid #cbd5e1", padding: "4px" }}>
                <p>ចំណាត់ថ្នាក់</p>
              </th>
              <th className="border border-slate-300 p-1" style={{ width: "63px", border: "1px solid #cbd5e1", padding: "4px" }}>
                <p>មធ្យមភាគ</p>
              </th>
              <th className="border border-slate-300 p-1" style={{ width: "48px", border: "1px solid #cbd5e1", padding: "4px" }}>
                <p>ចំណាត់ថ្នាក់</p>
              </th>
              <th className="border border-slate-300 p-1" style={{ width: "28px", border: "1px solid #cbd5e1", padding: "4px" }}>
                <p>ច្ប</p>
              </th>
              <th className="border border-slate-300 p-1" style={{ width: "28px", border: "1px solid #cbd5e1", padding: "4px" }}>
                <p>អច្ប</p>
              </th>
              <th className="border border-slate-300 p-1" style={{ width: "28px", border: "1px solid #cbd5e1", padding: "4px" }}>
                <p>សរុប</p>
              </th>
            </tr>
          </thead>
          <tbody>
            {annualData.map((row, idx) => {
              const s = row.student;
              const fullName = `${s.lastName || ""} ${s.firstName || ""}`.trim();
              const addrParts: string[] = [];
              if (s.village) addrParts.push(s.village.startsWith("ភូមិ") ? s.village : `ភូមិ${s.village}`);
              if (s.commune) addrParts.push(s.commune.startsWith("ឃុំ") || s.commune.startsWith("សង្កាត់") ? s.commune : `ឃុំ${s.commune}`);
              if (s.district) addrParts.push(s.district.startsWith("ស្រុក") || s.district.startsWith("ក្រុង") || s.district.startsWith("ខណ្ឌ") ? s.district : `ស្រុក${s.district}`);
              if (s.province) addrParts.push(s.province.startsWith("ខេត្ត") || s.province.startsWith("រាជធានី") ? s.province : `ខេត្ត${s.province}`);
              const address = addrParts.join(" ") || "—";
              const gradeInfo = row.annualAvg !== null ? gradeOf(row.annualAvg) : { l: "—", c: "#64748b" };

              return (
                <tr key={s.id} className={idx % 2 === 0 ? "bg-white" : "bg-slate-50/50"}>
                  <td className="border border-slate-300 p-1 text-center font-semibold" style={{ border: "1px solid #cbd5e1", padding: "3px" }}>
                    {idx + 1}
                  </td>
                  <td className="border border-slate-300 p-1 text-left font-bold text-slate-900 whitespace-nowrap" style={{ border: "1px solid #cbd5e1", padding: "3px", textAlign: "left" }}>
                    {fullName}
                  </td>
                  <td className="border border-slate-300 p-1 text-center" style={{ border: "1px solid #cbd5e1", padding: "3px" }}>
                    {s.gender || "—"}
                  </td>
                  <td className="border border-slate-300 p-1 text-center whitespace-nowrap" style={{ border: "1px solid #cbd5e1", padding: "3px" }}>
                    {s.dob || "—"}
                  </td>
                  <td className="border border-slate-300 p-1 text-left text-[10px] whitespace-nowrap" style={{ border: "1px solid #cbd5e1", padding: "3px 6px", textAlign: "left", whiteSpace: "nowrap" }}>
                    {address}
                  </td>
                  <td className="border border-slate-300 p-1 text-center font-semibold" style={{ border: "1px solid #cbd5e1", padding: "3px" }}>
                    {row.s1Avg !== null ? fmtAvg(row.s1Avg) : "—"}
                  </td>
                  <td className="border border-slate-300 p-1 text-center font-semibold" style={{ border: "1px solid #cbd5e1", padding: "3px" }}>
                    {row.s1Rank !== null ? row.s1Rank : "—"}
                  </td>
                  <td className="border border-slate-300 p-1 text-center font-semibold" style={{ border: "1px solid #cbd5e1", padding: "3px" }}>
                    {row.s2Avg !== null ? fmtAvg(row.s2Avg) : "—"}
                  </td>
                  <td className="border border-slate-300 p-1 text-center font-semibold" style={{ border: "1px solid #cbd5e1", padding: "3px" }}>
                    {row.s2Rank !== null ? row.s2Rank : "—"}
                  </td>
                  <td className="border border-slate-300 p-1 text-center font-bold text-blue-900" style={{ border: "1px solid #cbd5e1", padding: "3px", color: "#1e3a8a" }}>
                    {row.annualAvg !== null ? fmtAvg(row.annualAvg) : "—"}
                  </td>
                  <td className="border border-slate-300 p-1 text-center font-bold text-blue-900" style={{ border: "1px solid #cbd5e1", padding: "3px", color: "#1e3a8a" }}>
                    {row.annualRank !== null ? row.annualRank : "—"}
                  </td>
                  <td className="border border-slate-300 p-1 text-center font-black" style={{ border: "1px solid #cbd5e1", padding: "3px", color: gradeInfo.c }}>
                    {gradeInfo.l}
                  </td>
                  <td className="border border-slate-300 p-1 text-center" style={{ border: "1px solid #cbd5e1", padding: "3px" }}>
                    {row.pCount}
                  </td>
                  <td className="border border-slate-300 p-1 text-center" style={{ border: "1px solid #cbd5e1", padding: "3px" }}>
                    {row.aCount}
                  </td>
                  <td className="border border-slate-300 p-1 text-center font-bold" style={{ border: "1px solid #cbd5e1", padding: "3px" }}>
                    {row.totalAbs}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  };

  const computeCoreGradeStats = () => {
    const total = students.length || 1;
    const femaleTotal = students.filter((s) => s.gender === "ស្រី").length || 1;
    const khCounts: Record<string, number> = { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 };
    const khFemaleCounts: Record<string, number> = { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 };
    const mtCounts: Record<string, number> = { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 };
    const mtFemaleCounts: Record<string, number> = { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 };

    students.forEach((s) => {
      const r = computeCoreGradeRow(s);
      const isFemale = s.gender === "ស្រី";
      if (r.khCombined && khCounts[r.khCombined] !== undefined) {
        khCounts[r.khCombined]++;
        if (isFemale) khFemaleCounts[r.khCombined]++;
      }
      if (r.mtCombined && mtCounts[r.mtCombined] !== undefined) {
        mtCounts[r.mtCombined]++;
        if (isFemale) mtFemaleCounts[r.mtCombined]++;
      }
    });

    const khAbcCount = khCounts.A + khCounts.B + khCounts.C;
    const khDefCount = khCounts.D + khCounts.E + khCounts.F;
    const mtAbcCount = mtCounts.A + mtCounts.B + mtCounts.C;
    const mtDefCount = mtCounts.D + mtCounts.E + mtCounts.F;

    return {
      total,
      femaleTotal,
      khCounts,
      khFemaleCounts,
      mtCounts,
      mtFemaleCounts,
      khAbcPct: ((khAbcCount / total) * 100).toFixed(1) + "%",
      khDefPct: ((khDefCount / total) * 100).toFixed(1) + "%",
      mtAbcPct: ((mtAbcCount / total) * 100).toFixed(1) + "%",
      mtDefPct: ((mtDefCount / total) * 100).toFixed(1) + "%",
    };
  };

  // Export Core Grades XLSX
  const handleExportCoreGradesXLSX = () => {
    if (!students.length) return;
    const buildRows = (order: string[], title: string) => {
      const row0 = ["ល.រ", "គោត្តនាម-នាម", "ភេទ", "ថ្ងៃខែឆ្នាំកំណើត", title, ...Array(order.length - 1).fill(""), "និទ្ទេសរួម"];
      const row1 = ["", "", "", "", ...order, ""];
      const rows = [row0, row1];
      students.forEach((s, i) => {
        const r = computeCoreGradeRow(s);
        const grades = order === KH_ORDER ? r.khGrades : r.mtGrades;
        const combined = order === KH_ORDER ? r.khCombined : r.mtCombined;
        rows.push([i + 1, `${s.lastName} ${s.firstName}`, s.gender, s.dob || "", ...grades.map((g) => g || ""), combined || ""]);
      });
      return rows;
    };

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(buildRows(KH_ORDER, "លទ្ធផលតេស្ត មុខវិជ្ជាភាសាខ្មែរ")), "ភាសាខ្មែរ");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(buildRows(MT_ORDER, "លទ្ធផលតេស្ត មុខវិជ្ជាគណិតវិទ្យា")), "គណិតវិទ្យា");
    const semLabel = SEMESTERS.find((x) => x.id === semester)?.label || semester;
    XLSX.writeFile(wb, `coregrades_${selClass}_${semLabel}_${MONTHS[selMonth]}.xlsx`);
    toast("📥 Export និទ្ទេសគោល Excel រួចរាល់");
  };

  // Print Handler
  const handlePrintReport = () => {
    if (reportType === "studentcard") {
      const list = selectedStudentId === "__all__" ? students : students.filter((s) => s.id === selectedStudentId);
      const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>សៀវភៅតាមដាន - ថ្នាក់ទី ${selClass}</title><style>
        @import url('https://fonts.googleapis.com/css2?family=Battambang:wght@400;700;900&family=Hanuman:wght@400;700;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{font-family:'Hanuman','Battambang',sans-serif;background:#fff;padding:.4cm .5cm;}
        @page{size:A4 landscape;margin:.4cm .5cm;}
        .page-break{page-break-after:always;width:100%;}
        .page-break:last-child{page-break-after:auto;}
      </style></head><body>` + list.map((s) => `<div class="page-break">${buildStudentCardHTML(s, selClass, teacher, scoresMap, attendanceMap, selMonth, semester, students)}</div>`).join("") + `</body></html>`;
      printHTML(html);
      return;
    }

    if (reportType === "traineebook") {
      const list = selectedStudentId === "__all__" ? students : students.filter((s) => s.id === selectedStudentId);
      const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>សៀវភៅសិក្ខាគារិក - ថ្នាក់ទី ${selClass}</title><style>
        @import url('https://fonts.googleapis.com/css2?family=Battambang:wght@400;700;900&family=Hanuman:wght@400;700;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{font-family:'Hanuman','Battambang',sans-serif;background:#fff;padding:.4cm .5cm;}
        @page{size:A4 landscape;margin:.4cm .5cm;}
        .page-break{page-break-after:always;width:100%;}
        .page-break:last-child{page-break-after:auto;}
      </style></head><body>` + list.map((s, idx) => `<div class="page-break">${buildTraineeBookHTML(s, idx, selClass, teacher, scoresMap, attendanceMap, students, allMonthsScores, semester)}</div>`).join("") + `</body></html>`;
      printHTML(html);
      return;
    }

    if (reportType === "candidate") {
      const list = selectedStudentId === "__all__" ? students : students.filter((s) => s.id === selectedStudentId);
      const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>សលាកបត្របេក្ខជន</title><style>
        @import url('https://fonts.googleapis.com/css2?family=Battambang:wght@400;700;900&family=Hanuman:wght@400;700;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{font-family:'Hanuman','Battambang',sans-serif;background:#fff;}
        @page{size:A4 portrait;margin:10mm;}
        .page-break{page-break-after:always;}
      </style></head><body>` + list.map((s) => `<div class="page-break">${buildCandidateDocHTML(s, selClass, teacher, students, scoresMap, honorPhotos)}</div>`).join("") + `</body></html>`;
      printHTML(html);
      return;
    }

    if (reportType === "certificate") {
      const list = filteredStudents;
      if (list.length === 0) {
        toast("⚠️ ពុំមានសិស្សនៅក្នុងបញ្ជីជ្រើសរើសទេ", "error");
        return;
      }
      toast(`⏳ កំពុងបង្កើត QR Code សម្រាប់វិញ្ញាបនបត្រ (${list.length} នាក់)...`, "info");

      const qrPromises = list.map(async (s) => {
        const annualAvg = getAvg(s.id, students, scoresMap);
        const avgVal = annualAvg !== null ? Number(fmtAvg(annualAvg)) : null;
        const g = avgVal !== null ? gradeOf(avgVal).l : "—";
        const rank = getRank(s.id, students, scoresMap);
        const dataUrl = await generateStudentQRCodeDataUrl(s, selClass, schoolName, avgVal, g, rank);
        return { id: s.id, dataUrl };
      });

      Promise.all(qrPromises).then((qrResults) => {
        const qrMap = Object.fromEntries(qrResults.map((r) => [r.id, r.dataUrl]));
        const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>វិញ្ញាបនបត្របញ្ជាក់ការសិក្សា - ថ្នាក់ ${selClass} (${list.length} នាក់)</title><style>
          @import url('https://fonts.googleapis.com/css2?family=Battambang:wght@400;700;900&family=Hanuman:wght@400;700;900&display=swap');
          *{box-sizing:border-box;margin:0;padding:0;}
          body{font-family:'Hanuman','Battambang',sans-serif;background:#fff;}
          @page{size:A4 portrait;margin:10mm;}
          .page-break{page-break-after:always;}
          .page-break:last-child{page-break-after:auto;}
        </style></head><body>` + list.map((s) => `<div class="page-break">${buildCertificateHTML(s, selClass, teacher, students, scoresMap, qrMap[s.id])}</div>`).join("") + `</body></html>`;
        
        printHTML(html);
        toast(`✅ បានបង្កើតវិញ្ញាបនបត្រចំនួន ${list.length} ច្បាប់ រួចរាល់!`, "success");
      });
      return;
    }

    const previewEl = document.getElementById("reportDocContent");
    if (!previewEl) return;
    const html = `<!DOCTYPE html><html lang="km"><head><meta charset="UTF-8"><title>របាយការណ៍ - ថ្នាក់ទី ${selClass}</title><script src="https://cdn.tailwindcss.com"></script><link href="https://fonts.googleapis.com/css2?family=Hanuman:wght@400;700;900&family=Battambang:wght@400;700&display=swap" rel="stylesheet"><style>
      *{box-sizing:border-box;margin:0;padding:0;-webkit-print-color-adjust:exact !important;print-color-adjust:exact !important}
      body{font-family:'Hanuman','Battambang',sans-serif;font-size:11px;line-height:1.5;padding:.2cm .3cm;color:#0f172a;background:#fff;width:100%}
      @page{size:${reportType === "annual" ? "A4 landscape" : "A4 portrait"};margin:.2cm .3cm}
      #reportDocContent{padding:0 !important;border:none !important;box-shadow:none !important;width:100% !important;max-width:100% !important}
      
      .text-center{text-align:center !important}
      .text-left{text-align:left !important}
      .text-right{text-align:right !important}
      .font-bold{font-weight:700 !important}
      .font-black{font-weight:900 !important}
      .font-extrabold{font-weight:800 !important}
      .flex{display:flex !important}
      .justify-between{justify-content:space-between !important}
      .items-start{align-items:flex-start !important}
      .items-center{align-items:center !important}
      .gap-1{gap:4px !important}
      .gap-2{gap:8px !important}
      .gap-3{gap:12px !important}
      .gap-4{gap:16px !important}
      .mb-1{margin-bottom:4px !important}
      .mb-2{margin-bottom:8px !important}
      .mb-3{margin-bottom:12px !important}
      .mt-1{margin-top:4px !important}
      .mt-2{margin-top:8px !important}
      .w-full{width:100% !important}
      .pl-3{padding-left:12px !important}
      .pt-1{padding-top:4px !important}
      .pt-2.5,.pt-2{padding-top:8px !important}

      .grid{display:flex !important;gap:10px !important;align-items:stretch !important;width:100% !important}
      .grid-cols-2 > *{flex:1 !important;min-width:0 !important}
      .grid-cols-1 > *{width:100% !important}

      .rank-table{width:100% !important;border-collapse:collapse !important;font-size:12px !important}
      .rank-table th{background:#dbeafe !important;border:1px solid #93c5fd !important;padding:5px 2px !important;text-align:center !important;font-weight:700 !important;color:#1e3a8a !important}
      .rank-table td{border:1px solid #cbd5e1 !important;padding:4px 3px !important;height:28px !important;text-align:center !important}
      .rank-table th.text-left, .rank-table td.text-left{text-align:left !important;padding-left:6px !important}

      .sig-section{margin-top:14px !important;display:flex !important;justify-content:space-between !important;gap:8px !important}
      .sig-col{text-align:center !important;flex:1 !important}

      .g-A{color:#15803d !important;font-weight:800 !important}
      .g-B{color:#1d4ed8 !important;font-weight:800 !important}
      .g-C{color:#b45309 !important;font-weight:800 !important}
      .g-D{color:#c2410c !important;font-weight:800 !important}
      .g-E{color:#dc2626 !important;font-weight:800 !important}
      .g-F{color:#7f1d1d !important;font-weight:800 !important}
      .pass{color:#16a34a !important;font-weight:700 !important}
      .fail{color:#dc2626 !important;font-weight:700 !important}
      .no-print{display:none !important}
    </style></head><body>${previewEl.innerHTML}</body></html>`;
    printHTML(html);
  };

  return (
    <div className="p-3 space-y-3">
      {/* Report Type Selector Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200 no-print">
        <div className="flex flex-wrap gap-1.5 bg-slate-200/60 p-1 rounded-xl">
          {(
            [
              ["monthly", "📅 ប្រចាំខែ"],
              ["semester", "📚 ឆមាស"],
              ["annual", "🏆 ដំណាច់ឆ្នាំ"],
              ["attendance", "✅ វត្តមាន"],
              ["studentcard", "📖 សៀវភៅតាមដាន"],
              ["traineebook", "📕 សៀវភៅសិក្ខាគារិក"],
              ["candidate", "📜 សលាកបត្រ"],
              ["certificate", "🎓 វិញ្ញាបនបត្រ"],
              ["coregrade", "🎯 និទ្ទេសគោល"],
            ] as [ReportType, string][]
          ).map(([id, label]) => (
            <button
              key={id}
              onClick={() => onReportTypeChange(id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                reportType === id
                  ? "bg-white text-blue-600 shadow-sm"
                  : "text-slate-600 hover:text-blue-600"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap gap-2 items-center">
          {reportType === "coregrade" && (
            <>
              <button
                onClick={onSaveCoreGrades}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl transition shadow-sm"
              >
                💾 រក្សាទុក
              </button>
              <button
                onClick={handleExportCoreGradesXLSX}
                className="bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl transition shadow-sm"
              >
                📥 Excel
              </button>
              <button
                onClick={onOpenInvigilatorModal}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl transition shadow-sm"
              >
                🖋️ អនុរក្ស
              </button>
            </>
          )}

          {(reportType === "candidate" || reportType === "certificate" || reportType === "studentcard" || reportType === "traineebook") && (
            <select
              value={selectedStudentId}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-800 bg-white outline-none"
            >
              <option value="__all__">🏫 ពុម្ពទាំងថ្នាក់ (All Students)</option>
              {students.map((s, idx) => (
                <option key={s.id} value={s.id}>
                  {idx + 1}. {s.lastName} {s.firstName}
                </option>
              ))}
            </select>
          )}

          <button
            onClick={handlePrintReport}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-4 py-1.5 rounded-xl transition shadow-md shadow-blue-500/20"
          >
            🖨️ ព្រីន PDF
          </button>

          <button
            onClick={() => {
              const docElem = document.getElementById("reportDocContent");
              const htmlContent = docElem
                ? `<div style="font-family: 'Hanuman', 'Battambang', Arial, sans-serif; line-height: 1.5; color: #0f172a; padding: 15px; border: 1px solid #cbd5e1; border-radius: 8px;">${docElem.innerHTML}</div>`
                : `<p>របាយការណ៍លទ្ធផលសិក្សា - ថ្នាក់ទី ${selClass}</p>`;
              let reportName = `របាយការណ៍លទ្ធផលសិក្សា - ថ្នាក់ទី ${selClass}`;
              if (reportType === "monthly") reportName = `លទ្ធផលសិក្សាប្រចាំខែ ${MONTHS[selMonth]} - ថ្នាក់ទី ${selClass}`;
              else if (reportType === "semester") reportName = `លទ្ធផលសិក្សាប្រចាំឆមាស - ថ្នាក់ទី ${selClass}`;
              else if (reportType === "studentCard") reportName = `សៀវភៅសិក្ខាគារិក - ថ្នាក់ទី ${selClass}`;

              if (onOpenGmailModal) {
                onOpenGmailModal({
                  subject: `${reportName} - ${schoolName}`,
                  htmlBody: htmlContent,
                });
              }
            }}
            className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs px-4 py-1.5 rounded-xl transition shadow-md shadow-red-500/20 flex items-center gap-1.5"
          >
            ✉️ ផ្ញើតាម Gmail
          </button>
        </div>
      </div>

      {/* Student Filter Bar for Certificates & Individual Reports */}
      {(reportType === "certificate" || reportType === "candidate" || reportType === "studentcard" || reportType === "traineebook") && (
        <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white p-3 rounded-2xl shadow-lg no-print flex flex-wrap items-center justify-between gap-3 border border-blue-900/50">
          <div className="flex flex-wrap items-center gap-2.5 text-xs">
            {/* Search Input */}
            <div className="relative min-w-[180px]">
              <input
                type="text"
                placeholder="🔍 ស្វែងរកឈ្មោះសិស្ស..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-800/90 text-white placeholder-slate-400 border border-slate-700 rounded-xl px-3 py-1.5 text-xs outline-none focus:border-blue-400 transition"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Gender Filter */}
            <div className="flex items-center bg-slate-800/80 p-0.5 rounded-xl border border-slate-700">
              {[
                ["all", "ទាំងអស់"],
                ["ប្រុស", "👨 ប្រុស"],
                ["ស្រី", "👩 ស្រី"],
              ].map(([val, label]) => (
                <button
                  key={val}
                  onClick={() => setGenderFilter(val)}
                  className={`px-2.5 py-1 rounded-lg font-extrabold text-[11px] transition ${
                    genderFilter === val ? "bg-blue-600 text-white shadow-xs" : "text-slate-300 hover:text-white"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Result Filter */}
            <div className="flex items-center bg-slate-800/80 p-0.5 rounded-xl border border-slate-700">
              {[
                ["all", "លទ្ធផល"],
                ["pass", "✅ ជាប់"],
                ["fail", "❌ ធ្លាក់"],
              ].map(([val, label]) => (
                <button
                  key={val}
                  onClick={() => setResultFilter(val)}
                  className={`px-2.5 py-1 rounded-lg font-extrabold text-[11px] transition ${
                    resultFilter === val
                      ? val === "pass"
                        ? "bg-emerald-600 text-white"
                        : val === "fail"
                        ? "bg-rose-600 text-white"
                        : "bg-blue-600 text-white"
                      : "text-slate-300 hover:text-white"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Grade Filter */}
            <select
              value={gradeFilter}
              onChange={(e) => setGradeFilter(e.target.value)}
              className="bg-slate-800 text-white border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs font-bold outline-none cursor-pointer"
            >
              <option value="all">🏆 គ្រប់និទ្ទេស (A-F)</option>
              <option value="A">និទ្ទេស A</option>
              <option value="B">និទ្ទេស B</option>
              <option value="C">និទ្ទេស C</option>
              <option value="D">និទ្ទេស D</option>
              <option value="E">និទ្ទេស E</option>
              <option value="F">និទ្ទេស F</option>
            </select>

            {/* Clear All Filters */}
            {(searchQuery || genderFilter !== "all" || resultFilter !== "all" || gradeFilter !== "all" || selectedStudentId !== "__all__") && (
              <button
                onClick={() => {
                  setSearchQuery("");
                  setGenderFilter("all");
                  setResultFilter("all");
                  setGradeFilter("all");
                  setSelectedStudentId("__all__");
                }}
                className="text-amber-400 hover:text-amber-300 text-[11px] font-bold underline px-1"
              >
                🔄 កំណត់ឡើងវិញ
              </button>
            )}
          </div>

          {/* Student Count & Certificate Batch Action */}
          <div className="flex items-center gap-2">
            <div className="bg-blue-900/80 border border-blue-500/30 px-3 py-1 rounded-xl text-xs font-black text-blue-200">
              🎓 សិស្សជ្រើសរើស ៖ <span className="text-amber-300 text-sm">{filteredStudents.length}</span> / {students.length} នាក់
            </div>

            {reportType === "certificate" && (
              <button
                onClick={handlePrintReport}
                disabled={filteredStudents.length === 0}
                className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-xs px-3.5 py-1.5 rounded-xl transition shadow-md shadow-emerald-600/30 flex items-center gap-1.5 disabled:opacity-50"
              >
                <span>📜</span> <span>ព្រីនវិញ្ញាបនបត្រ PDF ({filteredStudents.length})</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Main Document Preview Container */}
      <div id="reportDocContent" className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm font-sans text-xs">
        {/* Kingdom Motto Header (Centered) */}
        <div className="text-center mb-2" style={{ textAlign: "center", width: "100%", marginBottom: "8px" }}>
          <h2 className="text-sm font-black text-slate-900 leading-tight" style={{ textAlign: "center", fontSize: "14px", fontWeight: 900, color: "#0f172a", lineHeight: 1.3 }}>
            ព្រះរាជាណាចក្រកម្ពុជា
            <br />
            ជាតិ សាសនា ព្រះមហាក្សត្រ
          </h2>
          <div className="text-[10px] text-amber-800 mt-0.5 font-normal" style={{ textAlign: "center", fontSize: "10px", color: "#92400e", marginTop: "2px" }}>꧁ ༺ ༻ ꧂</div>
        </div>

        {/* Administration Info (Left) & Invigilator Box (Right if coregrade) */}
        <div className="flex justify-between items-start gap-4 mb-2" style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "16px", width: "100%", marginBottom: "8px" }}>
          <div className="text-xs text-slate-900 leading-snug font-bold" style={{ fontSize: "12px", color: "#0f172a", lineHeight: 1.4, fontWeight: "bold" }}>
            <div>រដ្ឋបាលស្រុកភ្នំស្រុក</div>
            <div>ការិយាល័យអប់រំ យុវជន និងកីឡាស្រុក</div>
            <div>កម្រងស្ពានស្រែង</div>
            <div>{schoolName}</div>
          </div>

          {reportType === "coregrade" && (
            <div dangerouslySetInnerHTML={{ __html: buildInvigilatorBoxHTML(invigilatorData) }} />
          )}
        </div>

        <hr className="border-t-2 border-slate-900 mb-3" style={{ border: "none", borderTop: "2px solid #0f172a", marginBottom: "12px", width: "100%" }} />

        {/* Dynamic Titles */}
        {reportType === "monthly" && (
          <div className="text-center mb-3">
            <h3 className="text-base font-black text-slate-900">
              លទ្ធផលសិក្សាប្រចាំខែ {MONTHS[selMonth]}
            </h3>
            <p className="text-xs font-bold text-slate-800">ថ្នាក់ទី {selClass}</p>
          </div>
        )}

        {reportType === "semester" && (
          <div className="text-center mb-3">
            <h3 className="text-base font-black text-slate-900">
              លទ្ធផលសិក្សា {SEMESTERS.find((s) => s.id === semester)?.label}
            </h3>
            <p className="text-xs font-bold text-slate-800">ថ្នាក់ទី {selClass}</p>
          </div>
        )}

        {reportType === "annual" && (
          <div className="text-center mb-3">
            <h3 className="text-base font-black text-slate-900">ចំណាត់ថ្នាក់ដំណាច់ឆ្នាំ</h3>
            <p className="text-xs font-bold text-slate-800">ថ្នាក់ទី {selClass}</p>
          </div>
        )}

        {reportType === "coregrade" && (
          <div className="text-center mb-3">
            <h3 className="text-base font-black text-slate-900">
              លទ្ធផលតេស្ត (ABC) មុខវិជ្ជាភាសាខ្មែរ និងគណិតវិទ្យា
            </h3>
            <p className="text-xs font-bold text-slate-800">
              ថ្នាក់ទី {selClass} · {SEMESTERS.find((s) => s.id === semester)?.label} · ខែ
              {MONTHS[selMonth]}
            </p>
          </div>
        )}

        {/* Standard Academic Reports (Monthly, Semester, Annual, Attendance) */}
        {(reportType === "monthly" || reportType === "semester" || reportType === "annual" || reportType === "attendance") && (
          <div className="space-y-3">
            {reportType === "annual" ? (
              renderAnnualReportTable()
            ) : (
              /* 2-Column Split Student Tables for Monthly / Semester / Attendance */
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 items-start">
                <div>{renderRankTable(leftRanked, 0)}</div>
                <div>{rightRanked.length > 0 ? renderRankTable(rightRanked, halfIndex) : null}</div>
              </div>
            )}

            {/* Bottom Summary Statistics Section (Two Cards Side-by-Side as in sample image) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 text-[10.5px] leading-relaxed mt-2" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", marginTop: "8px" }}>
              {/* Left Box: Total Students & Grade Breakdown */}
              <div className="border border-slate-300 rounded-xl p-3 bg-slate-50/50 space-y-2">
                <div>
                  <div className="font-extrabold text-slate-900 flex items-center gap-1 mb-1">
                    <span>👥</span> <span>សិស្សទាំងអស់</span>
                  </div>
                  <div className="pl-1 text-slate-800">
                    -សរុប <strong className="font-bold text-slate-900">{stats.total}</strong>នាក់ ប្រុស <strong className="font-bold text-slate-900">{stats.male}</strong>នាក់ ({stats.malePct}%) ស្រី <strong className="font-bold text-slate-900">{stats.female}</strong>នាក់ ({stats.femalePct}%)
                  </div>
                </div>

                <div>
                  <div className="font-extrabold text-slate-900 flex items-center gap-1 mb-1">
                    <span>📊</span> <span>ចំណាត់ថ្នាក់ដោយនិទ្ទេស</span>
                  </div>
                  <div className="pl-1 space-y-0.5">
                    {(["A", "B", "C", "D", "E", "F"] as const).map((g) => {
                      const item = stats.grades[g];
                      return (
                        <div key={g} className="flex justify-between items-center text-slate-800">
                          <span>
                            -សិស្សនិទ្ទេស <strong className="font-extrabold" style={{ color: gradeOf(g === "A" ? 9.5 : g === "B" ? 8.5 : g === "C" ? 7.5 : g === "D" ? 6.8 : g === "E" ? 5.5 : 3).c }}>{g}</strong> សរុប <strong className="font-bold">{item.count}</strong>នាក់ ({item.pct}%)
                          </span>
                          <span className="text-slate-600 text-[10px]">
                            ស្រី <strong className="font-semibold">{item.female}</strong>នាក់ ({item.femalePct}%)
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Right Box: Pass/Fail Results & Percentages */}
              <div className="border border-slate-300 rounded-xl p-3 bg-slate-50/50 space-y-2">
                <div>
                  <div className="font-extrabold text-slate-900 flex items-center gap-1 mb-1">
                    <span>✅</span> <span>លទ្ធផលការប្រឡង</span>
                  </div>
                  <div className="pl-1 space-y-0.5 text-slate-800">
                    <div className="flex justify-between items-center">
                      <span>-ជាប់ <strong className="font-bold text-emerald-700">{stats.passCount}</strong>នាក់ ({stats.passPct}%)</span>
                      <span className="text-slate-600 text-[10px]">ស្រី <strong className="font-semibold text-emerald-700">{stats.passFemale}</strong>នាក់</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>-ធ្លាក់ <strong className="font-bold text-rose-700">{stats.failCount}</strong>នាក់ ({stats.failPct}%)</span>
                      <span className="text-slate-600 text-[10px]">ស្រី <strong className="font-semibold text-rose-700">{stats.failFemale}</strong>នាក់</span>
                    </div>
                  </div>
                </div>

                <div className="pt-1">
                  <div className="font-extrabold text-slate-900 flex items-center gap-1 mb-1">
                    <span>📈</span> <span>អត្រាប្រឡង</span>
                  </div>
                  <div className="pl-1 space-y-0.5 text-slate-800">
                    <div className="flex justify-between items-center">
                      <span>-អត្រាជាប់</span>
                      <strong className="font-extrabold text-emerald-700">{stats.passPct}%</strong>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>-អត្រាធ្លាក់</span>
                      <strong className="font-extrabold text-rose-700">{stats.failPct}%</strong>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {reportType === "coregrade" && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {/* Khmer Table */}
              <div>
                <h4 className="font-extrabold text-blue-900 text-xs mb-1 text-center">
                  📖 ភាសាខ្មែរ (៤ មុខវិជ្ជា)
                </h4>
                <table className="w-full text-[11px] border-collapse border border-slate-300 text-center">
                  <thead>
                    <tr className="bg-blue-100 font-bold">
                      <th className="border border-slate-300 p-1">ល.រ</th>
                      <th className="border border-slate-300 p-1 text-left">ឈ្មោះ</th>
                      <th className="border border-slate-300 p-1 w-8">ភេទ</th>
                      {KH_ORDER.map((k) => (
                        <th key={k} className="border border-slate-300 p-1 text-[9px]">
                          {k.replace("សមត្ថភាព", "")}
                        </th>
                      ))}
                      <th className="border border-slate-300 p-1">រួម</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((s, idx) => {
                      const r = computeCoreGradeRow(s);
                      return (
                        <tr key={s.id} className="border-b border-slate-200">
                          <td className="p-1">{idx + 1}</td>
                          <td className="p-1 text-left font-bold">
                            {s.lastName} {s.firstName}
                          </td>
                          <td className="p-1 text-center font-medium">{s.gender || "—"}</td>
                          {r.khGrades.map((g, i) => (
                            <td key={i} className="p-1 font-bold">
                              {g || "—"}
                            </td>
                          ))}
                          <td className="p-1 font-black text-blue-900">{r.khCombined || "—"}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Math Table */}
              <div>
                <h4 className="font-extrabold text-blue-900 text-xs mb-1 text-center">
                  🔢 គណិតវិទ្យា (៥ មុខវិជ្ជា)
                </h4>
                <table className="w-full text-[11px] border-collapse border border-slate-300 text-center">
                  <thead>
                    <tr className="bg-blue-100 font-bold">
                      <th className="border border-slate-300 p-1">ល.រ</th>
                      <th className="border border-slate-300 p-1 text-left">ឈ្មោះ</th>
                      <th className="border border-slate-300 p-1 w-8">ភេទ</th>
                      {MT_ORDER.map((m) => (
                        <th key={m} className="border border-slate-300 p-1 text-[9px]">
                          {m}
                        </th>
                      ))}
                      <th className="border border-slate-300 p-1">រួម</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((s, idx) => {
                      const r = computeCoreGradeRow(s);
                      return (
                        <tr key={s.id} className="border-b border-slate-200">
                          <td className="p-1">{idx + 1}</td>
                          <td className="p-1 text-left font-bold">
                            {s.lastName} {s.firstName}
                          </td>
                          <td className="p-1 text-center font-medium">{s.gender || "—"}</td>
                          {r.mtGrades.map((g, i) => (
                            <td key={i} className="p-1 font-bold">
                              {g || "—"}
                            </td>
                          ))}
                          <td className="p-1 font-black text-blue-900">{r.mtCombined || "—"}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Bottom Summary Table for Core Grade (ABC) */}
            {(() => {
              const coreStats = computeCoreGradeStats();
              const gradesList = ["A", "B", "C", "D", "E", "F"] as const;
              const gradeColors: Record<string, string> = {
                A: "#15803d",
                B: "#1d4ed8",
                C: "#b45309",
                D: "#c2410c",
                E: "#dc2626",
                F: "#7f1d1d",
              };

              return (
                <div className="space-y-3 pt-2 text-[10.5px] mt-2">
                  <div className="w-full overflow-x-auto">
                    <table className="w-full border-collapse border border-slate-300 text-center">
                      <thead>
                        <tr className="bg-blue-100/90 text-blue-950 font-bold">
                          <th rowSpan={2} className="border border-slate-300 p-1 text-center min-w-[75px]">
                            មុខវិជ្ជា
                          </th>
                          {gradesList.map((g) => (
                            <th key={g} colSpan={4} className="border border-slate-300 p-1 text-center" style={{ color: gradeColors[g] }}>
                              និទ្ទេស {g}
                            </th>
                          ))}
                        </tr>
                        <tr className="bg-blue-100/90 text-blue-950 font-bold text-[9px]">
                          {gradesList.map((g) => (
                            <React.Fragment key={g}>
                              <th className="border border-slate-300 p-0.5 w-6">សរុប</th>
                              <th className="border border-slate-300 p-0.5 w-7">%</th>
                              <th className="border border-slate-300 p-0.5 w-6 bg-pink-50/70 text-pink-950">ស្រី</th>
                              <th className="border border-slate-300 p-0.5 w-7 bg-pink-50/70 text-pink-950">%</th>
                            </React.Fragment>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {/* Khmer Row */}
                        <tr className="bg-white border-b border-slate-200">
                          <td className="border border-slate-300 p-1 text-left font-bold text-slate-900 whitespace-nowrap">
                            📖 ភាសាខ្មែរ
                          </td>
                          {gradesList.map((g) => {
                            const count = coreStats.khCounts[g] || 0;
                            const pct = coreStats.total > 0 ? ((count / coreStats.total) * 100).toFixed(1) + "%" : "0%";
                            const fCount = coreStats.khFemaleCounts[g] || 0;
                            const fPct = coreStats.femaleTotal > 0 ? ((fCount / coreStats.femaleTotal) * 100).toFixed(1) + "%" : "0%";
                            return (
                              <React.Fragment key={g}>
                                <td className="border border-slate-300 p-1 font-bold" style={{ color: gradeColors[g] }}>
                                  {count}
                                </td>
                                <td className="border border-slate-300 p-1 text-slate-700 text-[9.5px]">
                                  {pct}
                                </td>
                                <td className="border border-slate-300 p-1 font-bold text-pink-700 bg-pink-50/30">
                                  {fCount}
                                </td>
                                <td className="border border-slate-300 p-1 text-pink-800 text-[9.5px] bg-pink-50/30">
                                  {fPct}
                                </td>
                              </React.Fragment>
                            );
                          })}
                        </tr>
                        {/* Math Row */}
                        <tr className="bg-slate-50/50 border-b border-slate-200">
                          <td className="border border-slate-300 p-1 text-left font-bold text-slate-900 whitespace-nowrap">
                            🔢 គណិតវិទ្យា
                          </td>
                          {gradesList.map((g) => {
                            const count = coreStats.mtCounts[g] || 0;
                            const pct = coreStats.total > 0 ? ((count / coreStats.total) * 100).toFixed(1) + "%" : "0%";
                            const fCount = coreStats.mtFemaleCounts[g] || 0;
                            const fPct = coreStats.femaleTotal > 0 ? ((fCount / coreStats.femaleTotal) * 100).toFixed(1) + "%" : "0%";
                            return (
                              <React.Fragment key={g}>
                                <td className="border border-slate-300 p-1 font-bold" style={{ color: gradeColors[g] }}>
                                  {count}
                                </td>
                                <td className="border border-slate-300 p-1 text-slate-700 text-[9.5px]">
                                  {pct}
                                </td>
                                <td className="border border-slate-300 p-1 font-bold text-pink-700 bg-pink-50/30">
                                  {fCount}
                                </td>
                                <td className="border border-slate-300 p-1 text-pink-800 text-[9.5px] bg-pink-50/30">
                                  {fPct}
                                </td>
                              </React.Fragment>
                            );
                          })}
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* Summary Box for ABC vs DEF Rates */}
                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div className="border border-slate-300 rounded-lg p-2 bg-emerald-50/40 text-center">
                      <div className="text-[10px] font-bold text-emerald-900">📖 ភាសាខ្មែរ: ABC / DEF</div>
                      <div className="text-xs font-black mt-0.5 flex justify-center gap-4">
                        <span className="text-emerald-700">ABC: {coreStats.khAbcPct}</span>
                        <span className="text-rose-700">DEF: {coreStats.khDefPct}</span>
                      </div>
                    </div>
                    <div className="border border-slate-300 rounded-lg p-2 bg-blue-50/40 text-center">
                      <div className="text-[10px] font-bold text-blue-900">🔢 គណិតវិទ្យា: ABC / DEF</div>
                      <div className="text-xs font-black mt-0.5 flex justify-center gap-4">
                        <span className="text-emerald-700">ABC: {coreStats.mtAbcPct}</span>
                        <span className="text-rose-700">DEF: {coreStats.mtDefPct}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        )}

        {reportType === "studentcard" && (
          <div className="space-y-6">
            {filteredStudents.map((s) => (
              <div
                key={s.id}
                dangerouslySetInnerHTML={{
                  __html: buildStudentCardHTML(s, selClass, teacher, scoresMap, attendanceMap, selMonth, semester, students),
                }}
              />
            ))}
          </div>
        )}

        {reportType === "traineebook" && (
          <div className="space-y-6 overflow-x-auto">
            {filteredStudents.map((s, idx) => (
              <div
                key={s.id}
                dangerouslySetInnerHTML={{
                  __html: buildTraineeBookHTML(s, idx, selClass, teacher, scoresMap, attendanceMap, students, allMonthsScores, semester),
                }}
              />
            ))}
          </div>
        )}

        {reportType === "candidate" && (
          <div className="space-y-6">
            {filteredStudents.map((s) => (
              <div
                key={s.id}
                dangerouslySetInnerHTML={{
                  __html: buildCandidateDocHTML(s, selClass, teacher, students, scoresMap, honorPhotos),
                }}
              />
            ))}
          </div>
        )}

        {reportType === "certificate" && (
          <div className="space-y-6">
            {isGeneratingQr && (
              <div className="text-center py-4 text-blue-600 font-bold text-xs animate-pulse no-print">
                ⚡ កំពុងបង្កើត QR Code សម្រាប់ផ្ទៀងផ្ទាត់ព័ត៌មានសិស្ស...
              </div>
            )}
            {filteredStudents.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs font-bold bg-slate-50 rounded-2xl border border-dashed border-slate-300">
                🔍 ពុំមានទិន្នន័យសិស្សត្រូវតាមលក្ខខណ្ឌជ្រើសរើសឡើយ
              </div>
            ) : (
              filteredStudents.map((s) => (
                <div
                  key={s.id}
                  dangerouslySetInnerHTML={{
                    __html: buildCertificateHTML(s, selClass, teacher, students, scoresMap, certQrUrls[s.id]),
                  }}
                />
              ))
            )}
          </div>
        )}

        {/* Signature Box */}
        {reportType !== "candidate" && reportType !== "certificate" && reportType !== "studentcard" && reportType !== "traineebook" && (
          <div dangerouslySetInnerHTML={{ __html: buildSignatureHtml(tName, selMonth) }} />
        )}
      </div>
    </div>
  );
};

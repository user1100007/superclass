const fs = require('fs');
let code = fs.readFileSync('src/components/ReportsView.tsx', 'utf8');

const priOpt = `<option value="pri">🏫 តារាងសរុបពិន្ទុ PRI (សាលាបឋម)</option>`;
if (!code.includes(priOpt)) {
  code = code.replace(
    `<option value="coregrade">🎯 របាយការណ៍និទ្ទេសគោល (Core Grades)</option>`,
    `<option value="coregrade">🎯 របាយការណ៍និទ្ទេសគោល (Core Grades)</option>\n                  ${priOpt}`
  );
}

const renderPriReportFunc = `
  const renderPriReport = () => {
    const semId = semester !== "annual" ? semester : "s1";
    
    const initTally = () => ({
      female: Array(11).fill(0),
      male: Array(11).fill(0)
    });
    
    const tallies = {
      khmer: initTally(),
      math: initTally(),
      social: initTally(),
      science: initTally()
    };
    
    students.forEach(s => {
      let examScores = undefined;
      if (semId === "s1") examScores = allMonthsScores?.["s1_3"]?.[s.id];
      else if (semId === "s2") examScores = allMonthsScores?.["s2_7"]?.[s.id] || allMonthsScores?.["s2_8"]?.[s.id];
      
      if ((!examScores || Object.keys(examScores).length === 0) && semId === semester) {
        examScores = scoresMap[s.id];
      }
      if (!examScores) return;

      const isFemale = s.gender === "ស្រី";
      const gKey = isFemale ? "female" : "male";
      
      const getScore = (type: string) => {
        if (type === "khmer") {
           const raw = KH_ORDER.map(k => examScores[k]);
           const valids = raw.filter(v => v !== "" && v !== undefined && !isNaN(Number(v))).map(Number);
           return valids.length ? Math.round(valids.reduce((a,b)=>a+b,0)/valids.length) : null;
        } else if (type === "math") {
           const raw = MT_ORDER.map(k => examScores[k]);
           const valids = raw.filter(v => v !== "" && v !== undefined && !isNaN(Number(v))).map(Number);
           return valids.length ? Math.round(valids.reduce((a,b)=>a+b,0)/valids.length) : null;
        } else if (type === "social") {
           const v = examScores["សិក្សាសង្គម"];
           return (v !== "" && v !== undefined && !isNaN(Number(v))) ? Math.round(Number(v)) : null;
        } else if (type === "science") {
           const v = examScores["វិទ្យាសាស្ត្រ"];
           return (v !== "" && v !== undefined && !isNaN(Number(v))) ? Math.round(Number(v)) : null;
        }
        return null;
      };

      const kh = getScore("khmer");
      const mt = getScore("math");
      const soc = getScore("social");
      const sci = getScore("science");

      if (kh !== null && kh >= 0 && kh <= 10) tallies.khmer[gKey][kh]++;
      if (mt !== null && mt >= 0 && mt <= 10) tallies.math[gKey][mt]++;
      if (soc !== null && soc >= 0 && soc <= 10) tallies.social[gKey][soc]++;
      if (sci !== null && sci >= 0 && sci <= 10) tallies.science[gKey][sci]++;
    });

    const getRow = (title: string, data: any) => {
      const fTally = data.female;
      const fTotal = fTally.reduce((a: number, b: number) => a + b, 0);
      const fPassed = fTally.slice(5).reduce((a: number, b: number) => a + b, 0);
      
      const mTally = data.male;
      const mTotal = mTally.reduce((a: number, b: number) => a + b, 0);
      const mPassed = mTally.slice(5).reduce((a: number, b: number) => a + b, 0);

      return \`
        <tr>
          <td rowspan="2" class="border border-slate-300 p-1.5 text-left font-bold text-[12px]">\${title}</td>
          <td class="border border-slate-300 p-1.5 text-center text-[11px] font-bold">ស្រី</td>
          \${fTally.map((v: number) => \`<td class="border border-slate-300 p-1 text-center font-semibold text-[11px]">\${v || ''}</td>\`).join('')}
          <td class="border border-slate-300 p-1.5 text-center font-extrabold text-[11px] bg-blue-50/50 text-blue-900">\${fTotal || ''}</td>
          <td class="border border-slate-300 p-1.5 text-center font-extrabold text-[11px] bg-emerald-50/50 text-emerald-900">\${fPassed || ''}</td>
        </tr>
        <tr>
          <td class="border border-slate-300 p-1.5 text-center text-[11px] font-bold">ប្រុស</td>
          \${mTally.map((v: number) => \`<td class="border border-slate-300 p-1 text-center font-semibold text-[11px]">\${v || ''}</td>\`).join('')}
          <td class="border border-slate-300 p-1.5 text-center font-extrabold text-[11px] bg-blue-50/50 text-blue-900">\${mTotal || ''}</td>
          <td class="border border-slate-300 p-1.5 text-center font-extrabold text-[11px] bg-emerald-50/50 text-emerald-900">\${mPassed || ''}</td>
        </tr>
      \`;
    };

    const semLabel = SEMESTERS.find(s => s.id === semId)?.label || semId;

    return \`
      <div class="space-y-6 max-w-4xl mx-auto p-2">
        <div class="text-center mb-6">
          <h2 class="font-black text-sm mb-1 text-slate-900 leading-tight">
            ព្រះរាជាណាចក្រកម្ពុជា<br/>
            ជាតិ សាសនា ព្រះមហាក្សត្រ<br/>
            <span class="text-[10px] text-amber-800 font-normal">꧁ ༺ ༻ ꧂</span>
          </h2>
        </div>
        <div class="text-center mb-6">
          <h2 class="font-extrabold text-sm mb-1 text-slate-900">
            តារាងសរុបពិន្ទុសិស្សតាមមុខវិជ្ជាសម្រាប់បឋមសិក្សា<br/>
            ឆ្នាំសិក្សា២០២៥-២០២៦
          </h2>
          <p class="text-xs font-bold text-slate-700">(ពិន្ទុប្រឡងឆមាស - សម្រាប់គ្រូ PRI)</p>
        </div>
        
        <div class="flex justify-between items-end text-xs font-bold text-slate-800 mb-2 px-1">
          <div>សាលាបឋមសិក្សា៖ ..............................................</div>
          <div>ថ្នាក់ទី៖ <span class="text-blue-900 text-sm font-black">\${selClass}</span></div>
          <div>\${semLabel}</div>
        </div>

        <table class="w-full text-xs border-collapse border border-slate-400 text-center shadow-sm">
          <thead>
            <tr class="bg-slate-200/60 font-bold text-slate-900">
              <th rowspan="2" class="border border-slate-400 p-2 w-28 text-[12px]">មុខវិជ្ជា</th>
              <th rowspan="2" class="border border-slate-400 p-2 w-12 text-[12px]">ភេទ</th>
              <th colspan="11" class="border border-slate-400 p-1.5 text-[12px]">ចំនួនសិស្សស្រី/ប្រុសតាមកម្រិតពិន្ទុ និងមុខវិជ្ជា</th>
              <th rowspan="2" class="border border-slate-400 p-2 w-16 text-[11px] leading-tight">សរុប<br/>សិស្ស</th>
              <th rowspan="2" class="border border-slate-400 p-2 w-20 text-[11px] leading-tight">សរុប<br/>សិស្សជាប់</th>
            </tr>
            <tr class="bg-slate-200/60 font-bold text-[11px] text-slate-800">
              \${[0,1,2,3,4,5,6,7,8,9,10].map(v => \`<th class="border border-slate-400 p-1.5 w-7">\${v}</th>\`).join('')}
            </tr>
          </thead>
          <tbody>
            \${getRow("ភាសាខ្មែរ", tallies.khmer)}
            \${getRow("គណិតវិទ្យា", tallies.math)}
            \${getRow("សិក្សាសង្គម", tallies.social)}
            \${getRow("វិទ្យាសាស្ត្រ", tallies.science)}
          </tbody>
        </table>
        
        <div class="flex justify-between mt-12 text-[12px] font-bold text-slate-800 px-4">
          <div class="text-center">
            <p>បានឃើញ និងឯកភាព</p>
            <p class="mt-1">នាយកសាលា</p>
          </div>
          <div class="text-center">
            <p>ធ្វើនៅ ...................... ថ្ងៃទី ......... ខែ ............ ឆ្នាំ២០២....</p>
            <p class="mt-1">គ្រូប្រចាំថ្នាក់</p>
            <div class="mt-16 text-sm text-blue-900">\${teacher?.fullName || ""}</div>
          </div>
        </div>
      </div>
    \`;
  };
`;

if (!code.includes("renderPriReport()")) {
  code = code.replace(
    `const computeCoreGradeRow = (s: Student) => {`,
    `${renderPriReportFunc}\n\n  const computeCoreGradeRow = (s: Student) => {`
  );
  
  code = code.replace(
    `{reportType === "coregrade" && (`,
    `{reportType === "pri" && (
          <div dangerouslySetInnerHTML={{ __html: renderPriReport() }} />
        )}

        {reportType === "coregrade" && (`
  );
}

fs.writeFileSync('src/components/ReportsView.tsx', code);
console.log("Patched PRI report into ReportsView");

const fs = require('fs');
let code = fs.readFileSync('src/components/DetailTable.tsx', 'utf8');

const regex = /const firstThree = mAvgs\.slice\(0, 3\)\.filter\(\(v\): v is number => v !== null\);\s*const monthlyAvg =\s*firstThree\.length > 0\s*\?\s*firstThree\.reduce\(\(a, b\) => a \+ b, 0\) \/ firstThree\.length\s*:\s*null;\s*let semAvg: number \| null = null;\s*if \(monthlyAvg !== null && mAvgs\.length > 3 && mAvgs\[3\] !== null\) \{\s*semAvg = \(monthlyAvg \+ mAvgs\[3\]\) \/ 2;\s*\} else if \(monthlyAvg !== null\) \{\s*semAvg = monthlyAvg;\s*\} else if \(mAvgs\.length > 3 && mAvgs\[3\] !== null\) \{\s*semAvg = mAvgs\[3\];\s*\}/g;

const replacement = `
    const validMAvgs = mAvgs.filter((v): v is number => v !== null);
    const monthlyAvg = validMAvgs.length > 0
      ? validMAvgs.reduce((a, b) => a + b, 0) / validMAvgs.length
      : null;

    let examScore: number | null = null;
    if (semesterId === "s1") {
      examScore = getMonthAvg(s.id, 3);
    } else if (semesterId === "s2") {
      examScore = getMonthAvg(s.id, 7) !== null ? getMonthAvg(s.id, 7) : getMonthAvg(s.id, 8);
    }

    let semAvg: number | null = null;
    if (monthlyAvg !== null && examScore !== null) {
      semAvg = (monthlyAvg + examScore) / 2;
    } else if (monthlyAvg !== null) {
      semAvg = monthlyAvg;
    } else if (examScore !== null) {
      semAvg = examScore;
    }
`;

if(code.match(regex)) {
  code = code.replace(regex, replacement);
  fs.writeFileSync('src/components/DetailTable.tsx', code);
  console.log("DetailTable patched");
} else {
  console.log("DetailTable regex not found");
}

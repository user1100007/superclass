const fs = require('fs');
let code = fs.readFileSync('src/components/ReportsView.tsx', 'utf8');

const regex = /const getSemesterAvgForStudent = \(sid: string, semId: "s1" \| "s2"\) => \{[\s\S]*?return null;\s*\};/g;

const replacement = `const getSemesterAvgForStudent = (sid: string, semId: "s1" | "s2") => {
      const semConfig = SEMESTERS.find((s) => s.id === semId);
      if (!semConfig) return null;
      
      // Calculate Monthly Average
      const mAvgs: number[] = [];
      semConfig.months.forEach((mIdx) => {
        const key = \`\${semId}_\${mIdx}\`;
        const monthData = allMonthsScores?.[key];
        if (monthData && monthData[sid]) {
          const stuScores = monthData[sid];
          const valids = Object.values(stuScores)
            .filter((v) => v !== "" && v !== null && v !== undefined && !isNaN(Number(v)))
            .map(Number);
          if (valids.length > 0) {
            const sum = valids.reduce((a, b) => a + b, 0);
            const evalCount = getClassEvalSubjectCount(students, scoresMap);
            mAvgs.push(sum / evalCount);
          }
        }
      });
      
      const monthlyAvg = mAvgs.length > 0 ? mAvgs.reduce((a, b) => a + b, 0) / mAvgs.length : null;
      
      // Calculate Exam Average
      let examScores = undefined;
      if (semId === "s1") {
        examScores = allMonthsScores?.["s1_3"]?.[sid];
      } else {
        examScores = allMonthsScores?.["s2_7"]?.[sid] || allMonthsScores?.["s2_8"]?.[sid];
      }
      
      let examAvg: number | null = null;
      if (examScores && Object.keys(examScores).length > 0) {
         let total = 0, hasAny = false;
         SUBJECTS.forEach(s => {
           const v = examScores![s];
           if (v !== undefined && v !== "" && v !== null && !isNaN(Number(v))) {
             total += Number(v);
             hasAny = true;
           }
         });
         if (hasAny) {
           const evalCount = getClassEvalSubjectCount(students, scoresMap);
           examAvg = truncate2(total / evalCount);
         }
      }
      
      if (monthlyAvg !== null && examAvg !== null) {
        return (monthlyAvg + examAvg) / 2;
      } else if (monthlyAvg !== null) {
        return monthlyAvg;
      } else if (examAvg !== null) {
        return examAvg;
      }
      return null;
    };`;

if(code.match(regex)) {
  code = code.replace(regex, replacement);
  fs.writeFileSync('src/components/ReportsView.tsx', code);
  console.log("ReportsView annual patched");
} else {
  console.log("ReportsView annual regex not found");
}

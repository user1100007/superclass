const fs = require('fs');
let code = fs.readFileSync('src/components/ReportsView.tsx', 'utf8');

const target = `const handlePrintReport = () => {`;
const replacement = `const handlePrintReport = () => {
    if (reportType === "pri") {
      const html = \`<!DOCTYPE html><html><head><meta charset="utf-8"><title>តារាងសរុបពិន្ទុ PRI - ថ្នាក់ទី \${selClass}</title><style>
        @import url('https://fonts.googleapis.com/css2?family=Battambang:wght@400;700;900&family=Hanuman:wght@400;700;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{font-family:'Hanuman','Battambang',sans-serif;background:#fff;padding:1cm;}
        @page{size:A4 landscape;margin:1cm;}
      </style></head><body>\` + renderPriReport() + \`</body></html>\`;
      printHTML(html);
      return;
    }`;

if (code.includes(target) && !code.includes('if (reportType === "pri") {')) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/components/ReportsView.tsx', code);
  console.log("Patched print handler for PRI report");
}
